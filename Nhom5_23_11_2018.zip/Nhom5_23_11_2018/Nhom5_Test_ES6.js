//Khai Báo Biến
//Let -> tạo ra biến chỉ sử dụng trong block bao quanh nó
/* 
    let x = 10;
    if (true) {
        let x = 20; // x này là x khác rồi đấy
        console.log(x); // in ra 20
    }
console.log(x); // in ra 10
*/
//var -> Tạo ra biến có chức năng truy cập trong suốt function chứa nó
//const dùng để khai báo một hằng số - là một giá trị không thay đổi được trong suốt quá trình chạy.
/*
var x = 10;
const A = 10;
   if (true) {
      var x = 20; // x ở đây cũng là x ở trên
      console.log(x); // in ra 20
      //A = A + 1; => A : không đổi
   }
console.log(x); // vẫn là 20
console.log(A);
*/
// Arrow Function
/*
//Nhiều tham số
var multiply = (x, y) => {
     return x * y 
};
console.log(multiply(5,4));
//Không có tham số
var docLogEs6 = () => {
     console.log("Hello World");
     } 
docLogEs6();
//class trong ES6

class Employee {
    //Constructor
    constructor (name, lop) {
        this.name = name;
        this.lop = lop;
    }
    setName (name) {
        this.name = name;
    }
    getName () {
        return this.name;
    }
    setLop (lop) {
        this.lop = lop;
    }
    getLop () {
        return this.lop;
    }
};


console.log( new Employee("Nhóm 5", "CD16TT2"));
*/
//Base class access
class Employee {
    getClassName () {
        return "Class Employee";
    }
};
class MaleEmployee extends Employee {
    getClassName () {
        return "Class MaleEmployee";
    }
    classClassName () {
        return super.getClassName();
    }
}
var employee = new MaleEmployee();
console.log(employee.classClassName());
